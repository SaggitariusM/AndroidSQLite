package com.example.programacion5a.practicasqlite;

import android.provider.BaseColumns;

/**
 * Created by programacion5a on 02/08/16.
 */
public class DBContract {
    public DBContract(){}
    public static class FeedEntry implements BaseColumns{
        public static final String TABLE_NAME="persona";
        public static final String COLUMN_NAME_ID="id";
        public static final String COLUM_NAME_TITLE="titulo";
        public static final String COLUM_NAME_SUBTITLE="subtitulo";
    }
}
