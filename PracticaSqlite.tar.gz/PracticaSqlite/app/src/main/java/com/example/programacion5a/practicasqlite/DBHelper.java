package com.example.programacion5a.practicasqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.example.programacion5a.practicasqlite.DBContract.FeedEntry;
/**
 * Created by programacion5a on 02/08/16.
 */
public class DBHelper extends SQLiteOpenHelper {
    private static final String TEXT_TYPE=" TEXT";
    private static final String COMMA_SEP=",";
    private static final String SQL_CREATE_ENTRIES=
            "CREATE TABLE "+ FeedEntry.TABLE_NAME+" ("
            +FeedEntry._ID+" INTEGER PRIMARY KEY,"
            +FeedEntry.COLUMN_NAME_ID + TEXT_TYPE+COMMA_SEP
            +FeedEntry.COLUM_NAME_TITLE + TEXT_TYPE+COMMA_SEP
            +FeedEntry.COLUM_NAME_SUBTITLE + TEXT_TYPE+")";
    private static final String SQL_DELETE_ENTRIES="DROP TABLE IF EXISTS "+FeedEntry.TABLE_NAME;

    public static final int DATABASE_VERSION=5;
    public static final String DATABASE_NAME="primera.db";
    public DBHelper(Context context){
        super(context,DATABASE_NAME,null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(SQL_CREATE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(SQL_DELETE_ENTRIES);
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db,oldVersion,newVersion);
    }
}
