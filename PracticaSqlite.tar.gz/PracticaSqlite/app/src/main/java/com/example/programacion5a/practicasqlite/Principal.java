package com.example.programacion5a.practicasqlite;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.database.*;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.programacion5a.practicasqlite.DBContract.FeedEntry;

public class Principal extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);
    }
    public void Ingresar_Datos(View view){
        EditText eid=(EditText)findViewById(R.id.etxt_id);
        EditText etitulo=(EditText)findViewById(R.id.etxt_titulo);
        EditText esubt=(EditText)findViewById(R.id.etxt_subtitulo);

        String id_o=eid.getText().toString();
        String titulo_o=etitulo.getText().toString();
        String subtitulo_o=esubt.getText().toString();


        DBHelper dbh=new DBHelper(view.getContext());
        SQLiteDatabase db=dbh.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put(FeedEntry.COLUMN_NAME_ID,id_o);
        values.put(FeedEntry.COLUM_NAME_TITLE,titulo_o);
        values.put(FeedEntry.COLUM_NAME_SUBTITLE,subtitulo_o);
        long nueva_fila;
        nueva_fila=db.insert(
                FeedEntry.TABLE_NAME,
                null,
                values
        );
        db.close();
        TextView eresultado=(TextView) findViewById(R.id.txtv_resultado);
        eresultado.setText("SE HA GUARDADO");
    }
    public void Leer_Datos(View view) {
        DBHelper dbh=new DBHelper(view.getContext());
        SQLiteDatabase db = dbh.getReadableDatabase();
        String[] projection = {
                FeedEntry._ID,
                FeedEntry.COLUM_NAME_TITLE,
                FeedEntry.COLUM_NAME_SUBTITLE
        };
        String sort_order = FeedEntry.COLUM_NAME_TITLE + " DESC";
        Cursor c = db.query(
                FeedEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null
        );
        TextView eresultado=(TextView) findViewById(R.id.txtv_resultado);
        eresultado.setText("SI ANTES C");
        Toast.makeText(this,"Registros: "+c.getCount(),Toast.LENGTH_SHORT).show();
        if(c!=null){
            String r="ID: ";
            c.moveToFirst();
            r=r+c.getLong(c.getColumnIndexOrThrow(FeedEntry._ID))+"\n"+
            "TITULO: "+c.getString(c.getColumnIndexOrThrow(FeedEntry.COLUM_NAME_TITLE))+"\n"
            +"SUBTITULO: "+c.getString(c.getColumnIndexOrThrow(FeedEntry.COLUM_NAME_SUBTITLE))+".\n";
            while (c.moveToNext()){
                r=r+"ID: "+c.getLong(c.getColumnIndexOrThrow(FeedEntry._ID))+"\n"
                +"TITULO: "+c.getString(c.getColumnIndexOrThrow(FeedEntry.COLUM_NAME_TITLE))+"\n"
                +"SUBTITULO: "+c.getString(c.getColumnIndexOrThrow(FeedEntry.COLUM_NAME_SUBTITLE))+".\n";
            }
            //long itemId=c.getLong(c.getColumnIndexOrThrow(FeedEntry._ID));
            eresultado.setText("RESULTADO:\n"+r);
        }
        else{
            eresultado.setText("ERROR");
        }
        db.close();

    }
}
